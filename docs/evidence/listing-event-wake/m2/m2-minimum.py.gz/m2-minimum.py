from pathlib import Path
import os,json,sys,contextlib
B=Path('/home/avillagran/.cache/files-100k-m2-check');os.environ.update(json.loads((B/'env.json').read_text()));sys.path.insert(0,str(B/'source/scripts'))
import memcheck,importlib.util
with (B/'minimum-memory-groups-1080.json').open('w') as out,contextlib.redirect_stdout(out):
 memory_status=memcheck.main(['--binary',str(B/'source/target/release/files'),'--width','1920','--height','1080','--physical-width','1920','--physical-height','1080','--count','10000','--scenario-budget-mb','50','--app-arg=--no-session','--timeout','30'])
print('memory_status',memory_status,flush=True)
spec=importlib.util.spec_from_file_location('startup_check',B/'source/scripts/startup-check.py');startup=importlib.util.module_from_spec(spec);spec.loader.exec_module(startup)
with (B/'minimum-startup.json').open('w') as out,contextlib.redirect_stdout(out):
 startup_status=startup.main(['--binary',str(B/'source/target/release/files'),'--directory',str(B/'fixtures/10000'),'--runs','10','--timing-only'])
print('startup_status',startup_status,flush=True)
