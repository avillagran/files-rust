from pathlib import Path
import os,json,subprocess,tarfile,hashlib
B=Path('/home/avillagran/.cache/files-100k-m2-check');R=Path('/run/user/1001')
env={**os.environ,'PATH':'/home/avillagran/.local/bin:/home/avillagran/.cargo/bin:'+os.environ['PATH'],'XDG_RUNTIME_DIR':str(R),'WAYLAND_DISPLAY':'wayland-1','HYPRLAND_INSTANCE_SIGNATURE':next((R/'hypr').iterdir()).name,'DBUS_SESSION_BUS_ADDRESS':'unix:path=/run/user/1001/bus'}
(B/'session-env.json').write_text(json.dumps({k:env[k] for k in ['PATH','XDG_RUNTIME_DIR','WAYLAND_DISPLAY','HYPRLAND_INSTANCE_SIGNATURE','DBUS_SESSION_BUS_ADDRESS']}));(B/'session-env.json').chmod(0o600)
# Start the installed driver only if its existing socket does not answer.
r=subprocess.run(['/home/avillagran/.local/bin/cua-driver','call','list_windows','{}'],env=env,capture_output=True,text=True)
if r.returncode:
 log=(B/'cua-start.log').open('w');p=subprocess.Popen(['/home/avillagran/.local/bin/cua-driver','serve','--socket','/home/avillagran/.cache/cua-driver/cua-driver.sock'],env=env,stdout=log,stderr=log,start_new_session=True);(B/'owned-cua-pid').write_text(str(p.pid));print('own_cua_start_pid',p.pid)
# Flea is unpacked, never installed or set default.
archive=B/'flea-v0.4.0-linux-aarch64.tar.gz';assert hashlib.sha256(archive.read_bytes()).hexdigest()=='0165eae1d858793c88c9f3bef2d59bcf0c8403f14b9a7da2944fee28d733302f'
with tarfile.open(archive) as t:t.extractall(B/'flea',filter='data')
for name in ['home','config','cache','data']:(B/'profile'/name).mkdir(parents=True,exist_ok=True)
env.update({'HOME':str(B/'profile/home'),'XDG_CONFIG_HOME':str(B/'profile/config'),'XDG_CACHE_HOME':str(B/'profile/cache'),'XDG_DATA_HOME':str(B/'profile/data'),'FLTK_BACKEND':'wayland','LC_ALL':'C.UTF-8'})
(B/'env.json').write_text(json.dumps(env));(B/'env.json').chmod(0o600)
for count in [10000,100000]:
 p=B/'fixtures'/str(count);p.mkdir(parents=True,exist_ok=True)
 for i in range(count):
  f=p/f'item-{i:06}.txt'
  if not f.exists():f.touch()
 assert len(list(p.iterdir()))==count
m=json.loads(subprocess.check_output(['hyprctl','monitors','-j'],env=env));(B/'monitors.json').write_text(json.dumps(m,indent=2));print('monitors',[{k:x[k] for k in ['name','width','height','scale']} for x in m]);print('fixtures_ready')
