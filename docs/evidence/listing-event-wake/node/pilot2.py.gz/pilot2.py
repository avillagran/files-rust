import bench,json
r=bench.run('files',100000,'wake2-pilot');(bench.B/'pilot2-result.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:r[k] for k in ['listing_state_ready_s','stable_pss_swap_kib','peak_pss_swap_kib','sample_errors']}))
