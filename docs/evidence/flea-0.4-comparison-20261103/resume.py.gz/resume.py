import bench,json,time
B=bench.B;rows=json.loads((B/'results.json').read_text())
for app,rep in [('flea','2-retry'),('flea',3),('files',3)]:
 r=bench.run(app,100000,rep);rows.append(r);(B/'results.json').write_text(json.dumps(rows,indent=2));print(json.dumps({k:r[k] for k in ['app','count','rep','mapped_s','listing_state_ready_s','peak_pss_swap_kib','stable_pss_swap_kib','geometry','sample_errors']}),flush=True);time.sleep(.4)
