from pathlib import Path
import json,os,subprocess
b=Path(__file__).resolve().parent
for count in [10000,100000]:
 p=b/'fixtures'/str(count);p.mkdir(parents=True,exist_ok=True)
 for i in range(count):
  f=p/f'item-{i:06}.txt'
  if not f.exists():f.touch()
 assert len(list(p.iterdir()))==count
for name in ['config','cache','data','home']:(b/'profile'/name).mkdir(parents=True,exist_ok=True)
e={**os.environ,**json.loads(Path('/var/tmp/files-flea-bench-env.json').read_text()),'HOME':str(b/'profile/home'),'XDG_CONFIG_HOME':str(b/'profile/config'),'XDG_CACHE_HOME':str(b/'profile/cache'),'XDG_DATA_HOME':str(b/'profile/data'),'FLTK_BACKEND':'wayland','LC_ALL':'C.UTF-8'}
(b/'env.json').write_text(json.dumps(e))
flea=b/'flea/flea-0.4.0-linux-x86_64/flea'
r=subprocess.run([str(flea),'--ui-state'],env=e,capture_output=True,text=True);(b/'flea-default-state.json').write_text(r.stdout);print(r.stdout[:1800],r.stderr)
log=(b/'pilot-flea.log').open('w');p=subprocess.Popen([str(flea),'--gui',str(b/'fixtures/10000')],env=e,stdout=log,stderr=log,start_new_session=True);(b/'pilot-flea-pid').write_text(str(p.pid));print('pilotpid',p.pid)
