from pathlib import Path
import json,statistics,hashlib,subprocess,gzip,shutil,os
B=Path(__file__).resolve().parent;O=Path('/home/node/Work/files/docs/evidence/flea-0.4-comparison-20261103');O.mkdir(parents=True,exist_ok=True)
rows=json.loads((B/'results.json').read_text());assert len(rows)==16
summary=[]
for count in [10000,100000]:
 for app in ['files','flea']:
  rr=[r for r in rows if r['app']==app and r['count']==count];assert len(rr)==4
  assert all(r['geometry']['size']==[655,836] and not r['geometry']['xwayland'] and not r['sample_errors'] for r in rr)
  entry={'app':app,'count':count,'runs':4}
  for key in ['mapped_s','listing_state_ready_s','peak_pss_swap_kib','stable_pss_swap_kib']:
   x=[r[key] for r in rr];entry[key]={'median':statistics.median(x),'min':min(x),'max':max(x)}
  summary.append(entry)
files={'files':'/home/node/Work/files/target/release/files','files-helper':'/home/node/Work/files/target/release/files-helper','flea':str(B/'flea/flea-0.4.0-linux-x86_64/flea'),'flea-gui':str(B/'flea/flea-0.4.0-linux-x86_64/flea-gui')}
a={'date':'2026-11-03','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'flea_tag':'v0.4.0','flea_tag_commit':'22fa922','flea_release_asset_sha256':hashlib.sha256((B/'flea-v0.4.0-linux-x86_64.tar.gz').read_bytes()).hexdigest(),'artifact_sha256':{k:hashlib.sha256(Path(p).read_bytes()).hexdigest() for k,p in files.items()},'host':'NODE','cpu':'AMD Ryzen 9 5900X','renderer_flea':'Vulkan NVIDIA GeForce RTX 3080 Ti (confirmed every launch log)','renderer_files':'FLTK software Wayland','display':'1920x1080 scale1; observed client655x836 nativeWayland, identical geometry every timed run','fixture':'10000 and100000 empty .txt, same raw names/name sort,List view,own btrfs fixtures; default app row density differs','protocol':'4 valid runs per app/count alternating AB/BA; same shared private clean HOME/XDG configs/cache; real desktop background not killed, no build while measurements, samples~40-59ms incl overhead; own process group only cleanup','cache':'Directory metadata primed before each size; warm filesystem cache/fresh process, no global cache drop, no true cold-start result','memory':'Process-tree summed PSS+SwapPss including observed helpers; sampled peak is lower bound; settled median from>=max(ready+1s,3s) until>=max(5s,ready+3s); GPU memory separately recorded, NOT added blindly to PSS','timings':'External monotonic polling. Mapped is compositor client appearance, not usable. Listing state Files loaded/errorfree+expectedcount through existing FILES_METRICS_READY; Flea listingWindowState total+loaded>0, state ready, mounted drawnCount>0 through IPC. Different app observers, NOT OS-input or scanout latency. Poll quantization tens of ms; RPC overhead included for Flea. No frame/scroll/input latency claim','failure':'Initial 100k Flea rep2 IPC returned non-JSON before adapter ready; harness parser raised, own group terminated, raw log preserved. Parser now treats non-JSON as not-yet-ready; replacement rep2-retry and remaining original schedule complete. Invalid run excluded, not app failure','summary':summary,'decision':'Strict criterion LOWER MEMORY AND FASTER across tested listing workloads NOT MET: Files lower process-tree RAM both, faster listing10k, slower listing100k. No broad superiority or automatic feature-development continuation claim. Project not deleted/archived.','unmeasured':['True cold cache','Native input-to-visible-response, scrolling, navigation and search latency; computer-use driver unavailable, no ad-hoc input fallback','Media workload/equivalent thumbnail generation','Long-lifetime/leaks/power/CPU performance or bulk sync','Other machines/graphics drivers/complete feature parity'],'freeze':'User explicitly lifted prior resource/startup freeze ONLY for this comparison; unrelated experiments remain frozen'}
(O/'assessment.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');shutil.copy2(B/'results.json',O/'results.json')
notes=[]
for p in sorted(B.glob('*')):
 if p.name in ['env.json','flea-default-state.json','context-probe.json','flea-tree.json']:continue
 if p.suffix in ['.log','.py'] or p.name.endswith('-samples.json') or p.name.endswith('-drm.json') or p.name.startswith('validation-') or p.name=='manifest-initial.json':
  # No captured user window titles; manifest contains only display/session/identity.
  raw=p.read_bytes()
  if p.suffix=='.png':dest=O/p.name;dest.write_bytes(raw)
  else:dest=O/(p.name+'.gz');dest.write_bytes(gzip.compress(raw,mtime=0))
  notes.append({'file':dest.name,'original_name':p.name,'uncompressed_sha256':hashlib.sha256(raw).hexdigest()})
(O/'archives.json').write_text(json.dumps(notes,indent=2)+'\n')
# Inline responsive charts, independent scales and explicit warm-cache scope.
parts=[]
for count in [10000,100000]:
 parts.append(f'<section><h3>{count:,} archivos</h3>')
 for key,label,unit,scale in [('stable_pss_swap_kib','RAM del árbol · menos es mejor','MiB',1024),('listing_state_ready_s','Estado del listado listo · menos es mejor','ms',.001)]:
  rr=[x for x in summary if x['count']==count];vals=[x[key]['median']/scale for x in rr];maximum=max(vals)
  parts.append(f'<p class="metric">{label}</p>')
  for x,value in zip(rr,vals):
   col='var(--chart-1)' if x['app']=='files' else 'var(--chart-2)';parts.append(f'<div class="row"><span>{x["app"].title()}</span><div class="track"><div style="width:{100*value/maximum:.2f}%;background:{col}"></div></div><b>{value:.1f} {unit}</b></div>')
 parts.append('</section>')
html='''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font-family:var(--font-sans);color:var(--foreground);margin:0}h3{font-size:16px;margin:0 0 12px}section{margin:12px 0 24px}.metric{font-size:13px;color:var(--muted-foreground);margin:14px 0 6px}.row{display:grid;grid-template-columns:45px 1fr 88px;gap:10px;align-items:center;margin:8px 0;font-size:13px}.track{height:17px;background:var(--secondary);border-radius:3px}.track div{height:17px;border-radius:3px}.row b{font-family:var(--font-mono);font-size:12px;text-align:right}.note{font-size:12px;color:var(--muted-foreground);line-height:1.5}</style></head><body>'''+''.join(parts)+'''<p class="note">Medianas de 4 pasadas por aplicación y carpeta. NODE · Wayland · misma ventana 655×836 · caché de archivos precalentada.<br>RAM: PSS + SwapPss de proceso y helpers; GPU aparte. Listado listo: estado reportado por cada app; no latencia de teclado ni scroll.</p></body></html>'''
(B/'comparison.html').write_text(html);(O/'comparison.html').write_text(html)
print(json.dumps(summary,indent=2))
