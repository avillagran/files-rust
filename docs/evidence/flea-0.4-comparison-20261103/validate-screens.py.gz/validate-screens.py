import bench,subprocess,time,os,signal,json
B=bench.B
for app in ['files','flea']:
 tag='validation-'+app;log=(B/(tag+'.log')).open('w');cmd=([str(bench.FILES),str(B/'fixtures/100000'),'--list','--no-session'] if app=='files' else [str(bench.FLEA),'--gui',str(B/'fixtures/100000')])
 p=subprocess.Popen(cmd,env=bench.ENV,stdout=log,stderr=log,start_new_session=True)
 try:
  time.sleep(2)
  c=next(c for c in bench.clients() if c['pid']==p.pid)
  x,y=c['at'];w,h=c['size'];subprocess.run(['grim','-g',f'{x},{y} {w}x{h}',str(B/(tag+'.png'))],env=bench.ENV,check=True)
  if app=='flea':(B/(tag+'-state.json')).write_text(json.dumps({k:bench.call(p.pid,k) for k in ['total','state','listingWindowState','visibleRowName','statusPrimary']}))
 finally:
  os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3);log.close()
