from pathlib import Path
import os,json,tarfile,hashlib,subprocess,platform
B=Path('/home/intel/.cache/files-flea-comparison-20261104');assert 'GenuineIntel' in Path('/proc/cpuinfo').read_text() and platform.machine()=='x86_64'
for name in ['files-intel-trial.tar.gz','flea-v0.4.0-linux-x86_64.tar.gz']:
 with tarfile.open(B/name) as t:t.extractall(B,filter='data')
trial=B/'files-intel-trial';m=json.loads((trial/'manifest.json').read_text())
for name,h in m['files'].items():assert hashlib.sha256((trial/name).read_bytes()).hexdigest()==h,name
assert hashlib.sha256((B/m['flea_asset']).read_bytes()).hexdigest()==m['flea_asset_sha256']
R=Path('/run/user')/str(os.getuid());sockets=[p for p in R.glob('wayland-*') if p.is_socket()];assert len(sockets)==1,sockets;instances=[p for p in (R/'hypr').iterdir() if p.is_dir()];assert len(instances)==1
for name in ['home','config','cache','data']:(B/'profile'/name).mkdir(parents=True,exist_ok=True)
e={k:v for k,v in os.environ.items() if k in ['PATH','USER','LOGNAME','LANG','LC_ALL','TERM']};e.update({'HOME':str(B/'profile/home'),'XDG_CONFIG_HOME':str(B/'profile/config'),'XDG_CACHE_HOME':str(B/'profile/cache'),'XDG_DATA_HOME':str(B/'profile/data'),'XDG_RUNTIME_DIR':str(R),'WAYLAND_DISPLAY':sockets[0].name,'HYPRLAND_INSTANCE_SIGNATURE':instances[0].name,'DBUS_SESSION_BUS_ADDRESS':f'unix:path={R}/bus','FLTK_BACKEND':'wayland','LC_ALL':'C.UTF-8'})
(B/'env.json').write_text(json.dumps(e));(B/'env.json').chmod(0o600)
for app in [trial/'files',B/'flea-0.4.0-linux-x86_64/flea']:
 r=subprocess.run([str(app),'--version'],env=e,capture_output=True,text=True,timeout=5);assert r.returncode==0,(r.stdout,r.stderr);print(app.name,r.stdout.strip(),r.stderr.strip())
mon=json.loads(subprocess.check_output(['hyprctl','monitors','-j'],env=e));clients=json.loads(subprocess.check_output(['hyprctl','clients','-j'],env=e));print('monitors',[{k:x[k] for k in ['id','name','width','height','scale']} for x in mon]);print('existing_target_windows',[(c['pid'],c['class']) for c in clients if c['class'] in ['files','com.thisisgm.flea']]);assert not any(c['class'] in ['files','com.thisisgm.flea'] for c in clients)
for count in [10000,100000]:
 p=B/'fixtures'/str(count);p.mkdir(parents=True,exist_ok=True)
 for i in range(count):
  f=p/f'item-{i:06}.txt'
  if not f.exists():f.touch()
 assert len(list(p.iterdir()))==count
source=(trial/'bench-template.py').read_text().replace("sys.path.insert(0,'/home/node/Work/files/scripts')","sys.path.insert(0,str(B/'files-intel-trial'))").replace("FILES=Path('/home/node/Work/files/target/release/files');FLEA=B/'flea/flea-0.4.0-linux-x86_64/flea'","FILES=B/'files-intel-trial/files';FLEA=B/'flea-0.4.0-linux-x86_64/flea'")
source=source.replace("r=subprocess.run(['nvidia-smi','-q','-x'],capture_output=True,text=True,timeout=3)","import shutil,types\n  r=subprocess.run(['nvidia-smi','-q','-x'],capture_output=True,text=True,timeout=3) if shutil.which('nvidia-smi') else types.SimpleNamespace(returncode=1,stdout='')")
compile(source,str(B/'bench.py'),'exec');(B/'bench.py').write_text(source)
manifest={'host':'mbp-intel','cpu':'Intel Corei5-5257U,2cores/4threads','gpu':'Intel Iris6100/Broadwell,i915','memory_total_kib':int(Path('/proc/meminfo').read_text().splitlines()[0].split()[1]),'kernel':str(os.uname()),'libc':platform.libc_ver(),'monitors':mon,'code_commit':m['code_commit'],'artifacts':m['files'],'loadavg_setup':os.getloadavg(),'scope':'Intel-specific experiment. Target executables unpacked only; no installation/defaults changed.'};(B/'host-manifest.json').write_text(json.dumps(manifest,indent=2));print('fixtures_ready; artifacts verified')
