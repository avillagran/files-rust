from pathlib import Path
import os,json,time,subprocess,signal,sys,statistics,re,hashlib
B=Path(__file__).resolve().parent
sys.path.insert(0,str(B/'files-intel-trial'))
from process_metrics import TreeSampler
ENV=json.loads((B/'env.json').read_text())
FILES=B/'files-intel-trial/files';FLEA=B/'flea-0.4.0-linux-x86_64/flea'

def call(pid,fn):
 r=subprocess.run([str(FLEA),'ipc','--pid',str(pid),'call','flea',fn],env=ENV,capture_output=True,text=True,timeout=.6)
 return r.stdout.strip() if r.returncode==0 else None

def clients():return json.loads(subprocess.check_output(['hyprctl','clients','-j'],env=ENV,timeout=1))

def run(app,count,rep):
 tag=f'{app}-{count}-{rep}'; log=(B/(tag+'.log')).open('w'); path=B/'fixtures'/str(count)
 e={**ENV,'FILES_METRICS_READY':'1'}
 cmd=([str(FILES),str(path),'--list','--no-session'] if app=='files' else [str(FLEA),'--gui',str(path)])
 begin=time.monotonic();p=subprocess.Popen(cmd,env=e,stdout=log,stderr=log,start_new_session=True)
 sampler=TreeSampler(p.pid,discovery='children');samples=[];mapped=None;ready=None;settled=None;geom=None;lastticks=None;idle=None;flea_state=None
 try:
  while time.monotonic()-begin<15:
   now=time.monotonic();s=sampler.sample();s['elapsed_s']=now-begin;samples.append(s)
   if p.poll() is not None:raise RuntimeError(f'app exited {p.returncode}')
   if mapped is None:
    cs=[c for c in clients() if c['pid'] in [q['pid'] for q in s['processes']]]
    if cs:
     mapped=time.monotonic()-begin;geom={k:cs[0][k] for k in ['size','at','xwayland','floating','monitor']}
   if ready is None:
    if app=='files':
     text=(B/(tag+'.log')).read_text()
     if re.search(rf'FILES_SCENE_READY view=list loaded=true entries={count} ',text):ready=time.monotonic()-begin
    elif mapped is not None:
     val=call(p.pid,'listingWindowState')
     if val:
      try: flea_state=json.loads(val)
      except json.JSONDecodeError: flea_state={}
      if flea_state.get('total')==count and flea_state.get('loaded',0)>0 and call(p.pid,'state')=='ready' and int(call(p.pid,'drawnCount') or '0')>0:ready=time.monotonic()-begin
   ticks=0
   for q in s['processes']:
    try:
     stat=Path('/proc',str(q['pid']),'stat').read_text().rsplit(')',1)[1].split();ticks+=int(stat[11])+int(stat[12])
    except FileNotFoundError:pass
   if ticks!=lastticks:idle=time.monotonic();lastticks=ticks
   if ready is not None and settled is None and idle is not None and time.monotonic()-idle>=.5:settled=time.monotonic()-begin
   if ready is not None and now-begin>=max(5,ready+3):break
   time.sleep(.04)
  if ready is None:raise RuntimeError('listing readiness timeout')
  # GPU resident memory is reported separately, not blindly added to PSS.
  gpu=[]
  for q in samples[-1]['processes']:
   for fd in Path('/proc',str(q['pid']),'fdinfo').glob('*'):
    try:
     txt=fd.read_text()
     if 'drm-' in txt:gpu.append({'pid':q['pid'],'fd':fd.name,'text':txt})
    except OSError:pass
  (B/(tag+'-drm.json')).write_text(json.dumps(gpu,indent=2))
  import shutil,types
  r=subprocess.run(['nvidia-smi','-q','-x'],capture_output=True,text=True,timeout=3) if shutil.which('nvidia-smi') else types.SimpleNamespace(returncode=1,stdout='')
  import xml.etree.ElementTree as ET
  nvgpu=[]
  if r.returncode==0:
   own={str(q['pid']) for q in samples[-1]['processes']}
   for row in ET.fromstring(r.stdout).findall('.//process_info'):
    if row.findtext('pid') in own:nvgpu.append({c.tag:c.text for c in row})
  vals=[s['memory_kib'] for s in samples];stable=[s['memory_kib'] for s in samples if s['elapsed_s']>=max(ready+1,3)]
  result={'app':app,'count':count,'rep':rep,'pid':p.pid,'mapped_s':mapped,'listing_state_ready_s':ready,'cpu_quiet_s':settled,'geometry':geom,'peak_pss_swap_kib':max(vals),'stable_pss_swap_kib':statistics.median(stable),'last_processes':samples[-1]['processes'],'sample_errors':[x for s in samples for x in s['errors']],'gpu_nvidia':nvgpu,'flea_listing_state':flea_state,'loadavg':os.getloadavg(),'samples':len(samples),'sample_max_gap_s':max(b['elapsed_s']-a['elapsed_s'] for a,b in zip(samples,samples[1:]))}
  (B/(tag+'-samples.json')).write_text(json.dumps(samples))
 finally:
  # Only the exact process group created above; never names/global kill lists.
  try:os.killpg(p.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:p.wait(timeout=3)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=2)
  log.close()
 result['exit_status']=p.returncode
 return result

if __name__=='__main__':
 rows=[]
 for count in [10000,100000]:
  # Prime directory metadata for both apps; these are WARM filesystem-cache tests.
  for p in (B/'fixtures'/str(count)).iterdir():p.stat()
  for rep in range(4):
   for app in (['files','flea'] if rep%2==0 else ['flea','files']):
    r=run(app,count,rep);rows.append(r);(B/'results.json').write_text(json.dumps(rows,indent=2))
    print(json.dumps({k:r[k] for k in ['app','count','rep','mapped_s','listing_state_ready_s','peak_pss_swap_kib','stable_pss_swap_kib','geometry','sample_errors']}),flush=True)
    time.sleep(.4)
